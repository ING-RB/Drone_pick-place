wstool
==========

Command-line tools for maintaining a workspace of projects from multiple version-control systems.

Installing
----------

Using the pypi package::

  $ pip install -U wstool
