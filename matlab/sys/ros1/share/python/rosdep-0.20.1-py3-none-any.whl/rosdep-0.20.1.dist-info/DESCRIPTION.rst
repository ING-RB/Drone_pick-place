Command-line tool for installing system dependencies on a variety of platforms.


