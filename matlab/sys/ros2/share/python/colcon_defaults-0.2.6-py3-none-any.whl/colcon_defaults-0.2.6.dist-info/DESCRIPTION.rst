colcon-defaults
===============

An extension for `colcon-core <https://github.com/colcon/colcon-core>`_ to provide custom default values for the command line arguments from a configuration file.

For more information about the format of the configuration file see `colcon.readthedocs.io <http://colcon.readthedocs.io/en/released/user/configuration.html#defaults-yaml>`_.


